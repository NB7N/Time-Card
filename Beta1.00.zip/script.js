const managerPIN = "1965";
const DATA_RETENTION_DAYS = 365;

let employees = JSON.parse(localStorage.getItem("employees") || "{}");
let entries = JSON.parse(localStorage.getItem("entries") || "{}");

let currentEmployee = null;
let employeeSearchText = "";

/* ------------------------- Utility Helpers ------------------------- */

function save() {
  localStorage.setItem("employees", JSON.stringify(employees));
  localStorage.setItem("entries", JSON.stringify(entries));
}

function show(id) {
  document.querySelectorAll(".screen").forEach(s => s.classList.add("hidden"));
  document.getElementById(id).classList.remove("hidden");
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function formatDateTime(value) {
  if (!value) return "";
  const d = new Date(value);
  if (isNaN(d)) return value;
  return d.toLocaleString();
}

function formatDateOnly(value) {
  const d = new Date(value);
  if (isNaN(d)) return "";
  return d.toLocaleDateString();
}

function formatHours(hours) {
  return Number(hours || 0).toFixed(2);
}

function formatMoney(amount) {
  return "$" + Number(amount || 0).toFixed(2);
}

function isValidPin(pin) {
  return /^\d{4,20}$/.test(pin);
}

function isValidName(name) {
  return name.trim().length >= 2;
}

function isValidPayRate(rate) {
  return !isNaN(rate) && Number(rate) >= 0;
}

function ensureEmployeeEntryArray(pin) {
  if (!entries[pin]) entries[pin] = [];
}

function getEmployeeRecord(pin) {
  const value = employees[pin];

  // Backward compatible:
  // old format: employees[pin] = "John"
  // new format: employees[pin] = { name: "John", rate: 18.5 }
  if (typeof value === "string") {
    return {
      name: value,
      rate: 0
    };
  }

  if (value && typeof value === "object") {
    return {
      name: String(value.name || "").trim(),
      rate: Number(value.rate || 0)
    };
  }

  return {
    name: "",
    rate: 0
  };
}

function getEmployeeName(pin) {
  return getEmployeeRecord(pin).name || "Unknown";
}

function getEmployeeRate(pin) {
  return Number(getEmployeeRecord(pin).rate || 0);
}

function setEmployeeRecord(pin, name, rate) {
  employees[pin] = {
    name: String(name).trim(),
    rate: Number(rate || 0)
  };
}

function getLastEntry(pin) {
  const list = entries[pin] || [];
  return list.length ? list[list.length - 1] : null;
}

function calculateHours(entry) {
  if (!entry || !entry.in || !entry.out) return 0;

  const start = new Date(entry.in);
  const end = new Date(entry.out);

  if (isNaN(start) || isNaN(end) || end <= start) return 0;

  // Backward compatible:
  // ignore old lunch fields if they exist
  return (end - start) / 3600000;
}

function normalizeDateStart(dateString) {
  return new Date(dateString + "T00:00:00");
}

function normalizeDateEnd(dateString) {
  return new Date(dateString + "T23:59:59.999");
}

function overlapsDateRange(entry, start, end) {
  if (!entry.in || !entry.out) return false;

  const entryStart = new Date(entry.in);
  const entryEnd = new Date(entry.out);

  if (isNaN(entryStart) || isNaN(entryEnd)) return false;
  return entryEnd >= start && entryStart <= end;
}

function safeMessage(text) {
  alert(text);
}

function getEntryReferenceDate(entry) {
  if (entry && entry.out) return new Date(entry.out);
  if (entry && entry.in) return new Date(entry.in);
  return null;
}

function cleanupOldData() {
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - DATA_RETENTION_DAYS);

  Object.keys(entries).forEach(pin => {
    if (!Array.isArray(entries[pin])) {
      entries[pin] = [];
      return;
    }

    entries[pin] = entries[pin].filter(entry => {
      const last = getEntryReferenceDate(entry);
      if (!last || isNaN(last)) return false;

      // Keep open shifts no matter what
      if (!entry.out) return true;

      return last >= cutoff;
    });
  });

  save();
}

function migrateData() {
  // Convert old employee format to new format
  Object.keys(employees).forEach(pin => {
    const record = getEmployeeRecord(pin);
    employees[pin] = {
      name: record.name,
      rate: Number(record.rate || 0)
    };
  });

  // Ensure entries structure and preserve backward compatibility
  Object.keys(entries).forEach(pin => {
    if (!Array.isArray(entries[pin])) {
      entries[pin] = [];
    }

    entries[pin] = entries[pin]
      .filter(entry => entry && typeof entry === "object" && entry.in)
      .map(entry => ({
        in: entry.in || null,
        out: entry.out || null,
        // preserve old lunch-related fields in storage, but they are ignored by app logic
        lunchOut: entry.lunchOut || null,
        lunchIn: entry.lunchIn || null,
        lunchStart: entry.lunchStart || null,
        lunchEnd: entry.lunchEnd || null
      }));
  });

  cleanupOldData();
  save();
}

/* ------------------------- Live Clock ------------------------- */

function updateLiveClocks() {
  const now = new Date().toLocaleString();
  const loginClock = document.getElementById("liveDateTime");
  const empClock = document.getElementById("employeeLiveTime");

  if (loginClock) loginClock.textContent = now;
  if (empClock) empClock.textContent = now;
}

setInterval(updateLiveClocks, 1000);

/* ------------------------- App Flow ------------------------- */

function logout() {
  currentEmployee = null;
  show("login");
  document.getElementById("pin").value = "";
  updateLiveClocks();
}

function login() {
  cleanupOldData();

  const pin = document.getElementById("pin").value.trim();

  if (!pin) {
    safeMessage("Please enter a PIN.");
    return;
  }

  if (pin === managerPIN) {
    show("manager");
    document.getElementById("managerContent").innerHTML = `
      <div class="empty-state">Select an option above to manage employees or run reports.</div>
    `;
    return;
  }

  if (employees[pin]) {
    currentEmployee = pin;
    openEmployee();
    return;
  }

  safeMessage("Invalid PIN.");
}

function openEmployee() {
  show("employee");
  document.getElementById("empName").textContent = "Hello " + getEmployeeName(currentEmployee);

  const last = getLastEntry(currentEmployee);
  const status = document.getElementById("employeeStatus");

  if (!last || last.out) {
    status.innerHTML = `<span class="badge info">Currently clocked out</span>`;
  } else {
    status.innerHTML = `<span class="badge success">Clocked in since ${escapeHtml(formatDateTime(last.in))}</span>`;
  }

  renderEmpButtons();
  renderEmployeeRecentEntries();
}

function renderEmpButtons() {
  const last = getLastEntry(currentEmployee);
  const div = document.getElementById("empButtons");
  div.innerHTML = "";

  if (!last || last.out) {
    div.innerHTML = `<button class="success" onclick="clockIn()">Clock In</button>`;
  } else {
    div.innerHTML = `<button class="warning" onclick="clockOut()">Clock Out</button>`;
  }
}

function renderEmployeeRecentEntries() {
  const container = document.getElementById("employeeRecentEntries");
  const list = (entries[currentEmployee] || []).slice().reverse().slice(0, 10);

  if (!list.length) {
    container.innerHTML = `<div class="empty-state">No time entries yet.</div>`;
    return;
  }

  let html = `<div class="table-wrap"><table>
    <tr>
      <th>Clock In</th>
      <th>Clock Out</th>
      <th>Total Hours</th>
      <th>Status</th>
    </tr>`;

  list.forEach(entry => {
    const total = entry.out ? formatHours(calculateHours(entry)) + " hrs" : "-";
    const status = entry.out
      ? `<span class="badge info">Complete</span>`
      : `<span class="badge success">Open</span>`;

    html += `
      <tr>
        <td>${escapeHtml(formatDateTime(entry.in))}</td>
        <td>${escapeHtml(formatDateTime(entry.out) || "-")}</td>
        <td>${escapeHtml(total)}</td>
        <td>${status}</td>
      </tr>
    `;
  });

  html += `</table></div>`;
  container.innerHTML = html;
}

function clockIn() {
  ensureEmployeeEntryArray(currentEmployee);

  const last = getLastEntry(currentEmployee);
  if (last && !last.out) {
    safeMessage("You are already clocked in.");
    return;
  }

  entries[currentEmployee].push({
    in: new Date().toISOString(),
    out: null
  });

  save();
  safeMessage("Clocked in successfully.");
  openEmployee();
}

function clockOut() {
  const last = getLastEntry(currentEmployee);

  if (!last || last.out) {
    safeMessage("No active clock-in found.");
    return;
  }

  last.out = new Date().toISOString();
  save();
  safeMessage("Clocked out successfully.");
  openEmployee();
}

/* ------------------------- Manager: Employees ------------------------- */

function employeeManager() {
  const filter = employeeSearchText.trim().toLowerCase();

  const pins = Object.keys(employees)
    .sort((a, b) => getEmployeeName(a).localeCompare(getEmployeeName(b)))
    .filter(pin => {
      if (!filter) return true;
      return (
        getEmployeeName(pin).toLowerCase().includes(filter) ||
        pin.includes(filter) ||
        formatMoney(getEmployeeRate(pin)).toLowerCase().includes(filter)
      );
    });

  let html = `
    <div class="topbar">
      <div>
        <h3>Employees</h3>
        <p class="muted small">Add, edit, remove, and search employees.</p>
      </div>
      <button class="primary" onclick="addEmployee()">Add Employee</button>
    </div>

    <div class="search-bar">
      <div class="form-row">
        <label for="employeeSearch">Search Employees</label>
        <input
          id="employeeSearch"
          type="text"
          placeholder="Search by name, PIN, or pay rate"
          value="${escapeHtml(employeeSearchText)}"
          oninput="setEmployeeSearch(this.value)"
        />
      </div>
    </div>
  `;

  if (!pins.length) {
    html += `<div class="empty-state">No matching employees found.</div>`;
    document.getElementById("managerContent").innerHTML = html;
    return;
  }

  html += `<div class="table-wrap"><table>
    <tr>
      <th>Name</th>
      <th>PIN</th>
      <th>Hourly Pay</th>
      <th>Status</th>
      <th>Actions</th>
    </tr>`;

  pins.forEach(pin => {
    const last = getLastEntry(pin);
    const status = last && !last.out
      ? `<span class="badge success">Clocked In</span>`
      : `<span class="badge info">Clocked Out</span>`;

    html += `
      <tr>
        <td>${escapeHtml(getEmployeeName(pin))}</td>
        <td>${escapeHtml(pin)}</td>
        <td>${escapeHtml(formatMoney(getEmployeeRate(pin)))}</td>
        <td>${status}</td>
        <td>
          <div class="inline-actions">
            <button onclick="editEmployee('${pin}')">Edit</button>
            <button class="danger" onclick="deleteEmployee('${pin}')">Delete</button>
          </div>
        </td>
      </tr>
    `;
  });

  html += `</table></div>`;
  document.getElementById("managerContent").innerHTML = html;
}

function setEmployeeSearch(value) {
  employeeSearchText = value || "";
  employeeManager();
}

function addEmployee() {
  const name = prompt("Employee name:");
  if (name === null) return;

  if (!isValidName(name)) {
    safeMessage("Employee name must be at least 2 characters.");
    return;
  }

  const pin = prompt("PIN (numbers only, 4 to 20 digits):");
  if (pin === null) return;

  if (!isValidPin(pin)) {
    safeMessage("PIN must be numeric and 4 to 20 digits long.");
    return;
  }

  if (pin === managerPIN) {
    safeMessage("That PIN is reserved for manager access.");
    return;
  }

  if (employees[pin]) {
    safeMessage("That PIN already exists.");
    return;
  }

  const rateInput = prompt("Hourly pay rate (example: 18.50):", "0");
  if (rateInput === null) return;

  if (!isValidPayRate(rateInput)) {
    safeMessage("Hourly pay must be a valid number 0 or greater.");
    return;
  }

  setEmployeeRecord(pin, name.trim(), Number(rateInput));
  ensureEmployeeEntryArray(pin);
  save();
  employeeManager();
}

function editEmployee(pin) {
  const current = getEmployeeRecord(pin);

  const newName = prompt("Employee name:", current.name);
  if (newName === null) return;

  if (!isValidName(newName)) {
    safeMessage("Employee name must be at least 2 characters.");
    return;
  }

  const newPIN = prompt("PIN (numbers only, 4 to 20 digits):", pin);
  if (newPIN === null) return;

  if (!isValidPin(newPIN)) {
    safeMessage("PIN must be numeric and 4 to 20 digits long.");
    return;
  }

  if (newPIN === managerPIN) {
    safeMessage("That PIN is reserved for manager access.");
    return;
  }

  if (newPIN !== pin && employees[newPIN]) {
    safeMessage("That new PIN already belongs to another employee.");
    return;
  }

  const newRate = prompt("Hourly pay rate:", String(current.rate));
  if (newRate === null) return;

  if (!isValidPayRate(newRate)) {
    safeMessage("Hourly pay must be a valid number 0 or greater.");
    return;
  }

  const oldEntries = entries[pin] || [];

  delete employees[pin];
  delete entries[pin];

  setEmployeeRecord(newPIN, newName.trim(), Number(newRate));
  entries[newPIN] = oldEntries;

  save();
  employeeManager();
}

function deleteEmployee(pin) {
  const name = getEmployeeName(pin);
  if (!confirm(`Delete employee "${name}" and all time entries?`)) return;

  delete employees[pin];
  delete entries[pin];

  save();
  employeeManager();
}

/* ------------------------- Manager: Entry Editing ------------------------- */

function editEntries() {
  let html = `
    <h3>Edit Time Entries</h3>
    <p class="muted small">Edit or remove employee clock-in and clock-out records.</p>
    <div class="note-box">Old lunch data from previous versions is preserved for compatibility, but it is ignored in this version.</div>
  `;

  let hasEntries = false;

  html += `<div class="table-wrap"><table>
    <tr>
      <th>Employee</th>
      <th>Clock In</th>
      <th>Clock Out</th>
      <th>Total Hours</th>
      <th>Payroll</th>
      <th>Actions</th>
    </tr>`;

  Object.keys(entries).forEach(pin => {
    (entries[pin] || []).forEach((entry, i) => {
      hasEntries = true;
      const hours = calculateHours(entry);
      const payroll = hours * getEmployeeRate(pin);

      html += `
        <tr>
          <td>${escapeHtml(getEmployeeName(pin))}</td>
          <td>${escapeHtml(formatDateTime(entry.in))}</td>
          <td>${escapeHtml(formatDateTime(entry.out) || "-")}</td>
          <td>${entry.out ? escapeHtml(formatHours(hours) + " hrs") : "-"}</td>
          <td>${entry.out ? escapeHtml(formatMoney(payroll)) : "-"}</td>
          <td>
            <div class="inline-actions">
              <button onclick="editEntry('${pin}', ${i})">Edit</button>
              <button class="danger" onclick="deleteEntry('${pin}', ${i})">Delete</button>
            </div>
          </td>
        </tr>
      `;
    });
  });

  html += `</table></div>`;

  if (!hasEntries) {
    html += `<div class="empty-state">No entries to edit.</div>`;
  }

  document.getElementById("managerContent").innerHTML = html;
}

function editEntry(pin, i) {
  const entry = entries[pin][i];

  const newIn = prompt("Clock In (example: 2026-03-14T08:00:00):", entry.in || "");
  if (newIn === null) return;

  const newOut = prompt("Clock Out (leave blank if still clocked in):", entry.out || "");
  if (newOut === null) return;

  const inDate = new Date(newIn);
  if (isNaN(inDate)) {
    safeMessage("Clock In date/time is invalid.");
    return;
  }

  if (newOut.trim()) {
    const outDate = new Date(newOut);
    if (isNaN(outDate)) {
      safeMessage("Clock Out date/time is invalid.");
      return;
    }
    if (outDate <= inDate) {
      safeMessage("Clock Out must be later than Clock In.");
      return;
    }
  }

  const oldEntry = entries[pin][i];

  entries[pin][i] = {
    in: new Date(newIn).toISOString(),
    out: newOut.trim() ? new Date(newOut).toISOString() : null,
    lunchOut: oldEntry.lunchOut || null,
    lunchIn: oldEntry.lunchIn || null,
    lunchStart: oldEntry.lunchStart || null,
    lunchEnd: oldEntry.lunchEnd || null
  };

  save();
  editEntries();
}

function deleteEntry(pin, i) {
  if (!confirm("Delete this entry?")) return;
  entries[pin].splice(i, 1);
  save();
  editEntries();
}

/* ------------------------- Manager: Clocked In ------------------------- */

function showClocked() {
  let html = `
    <h3>Who's Clocked In</h3>
    <p class="muted small">Employees with an open shift right now.</p>
  `;

  let found = false;

  html += `<div class="table-wrap"><table>
    <tr>
      <th>Employee</th>
      <th>Since</th>
      <th>Elapsed</th>
      <th>Hourly Pay</th>
      <th>Status</th>
    </tr>`;

  Object.keys(entries).forEach(pin => {
    const last = getLastEntry(pin);
    if (last && !last.out) {
      found = true;
      const hours = ((new Date() - new Date(last.in)) / 3600000).toFixed(2);

      html += `
        <tr>
          <td>${escapeHtml(getEmployeeName(pin))}</td>
          <td>${escapeHtml(formatDateTime(last.in))}</td>
          <td>${escapeHtml(hours)} hrs</td>
          <td>${escapeHtml(formatMoney(getEmployeeRate(pin)))}</td>
          <td><span class="badge success">Clocked In</span></td>
        </tr>
      `;
    }
  });

  html += `</table></div>`;

  if (!found) {
    html += `<div class="empty-state">No employees are currently clocked in.</div>`;
  }

  document.getElementById("managerContent").innerHTML = html;
}

/* ------------------------- Payroll Reporting ------------------------- */

function payPeriod() {
  const now = new Date();
  let start, end;

  if (now.getDate() >= 11 && now.getDate() <= 25) {
    start = new Date(now.getFullYear(), now.getMonth(), 11);
    end = new Date(now.getFullYear(), now.getMonth(), 25);
  } else if (now.getDate() >= 26) {
    start = new Date(now.getFullYear(), now.getMonth(), 26);
    end = new Date(now.getFullYear(), now.getMonth() + 1, 10);
  } else {
    start = new Date(now.getFullYear(), now.getMonth() - 1, 26);
    end = new Date(now.getFullYear(), now.getMonth(), 10);
  }

  return { start, end };
}

function reportScreen() {
  show("report");
  const p = payPeriod();

  document.getElementById("reportStart").value = p.start.toISOString().split("T")[0];
  document.getElementById("reportEnd").value = p.end.toISOString().split("T")[0];
  document.getElementById("reportOutput").innerHTML = "";
  document.getElementById("reportSummary").innerHTML = "";
}

function generateReport() {
  cleanupOldData();

  const startValue = document.getElementById("reportStart").value;
  const endValue = document.getElementById("reportEnd").value;

  if (!startValue || !endValue) {
    safeMessage("Please select both start and end dates.");
    return;
  }

  const start = normalizeDateStart(startValue);
  const end = normalizeDateEnd(endValue);

  if (end < start) {
    safeMessage("End date must be on or after start date.");
    return;
  }

  let html = `<div class="table-wrap"><table>
    <tr>
      <th>Employee</th>
      <th>Hourly Pay</th>
      <th>Total Hours</th>
      <th>Shifts Count</th>
      <th>Payroll Total</th>
    </tr>`;

  let grandHours = 0;
  let grandPayroll = 0;
  let employeeCount = 0;
  let shiftCount = 0;

  Object.keys(employees)
    .sort((a, b) => getEmployeeName(a).localeCompare(getEmployeeName(b)))
    .forEach(pin => {
      let hours = 0;
      let shifts = 0;

      (entries[pin] || []).forEach(entry => {
        if (!entry.out) return;
        if (!overlapsDateRange(entry, start, end)) return;

        hours += calculateHours(entry);
        shifts++;
      });

      const rate = getEmployeeRate(pin);
      const payroll = hours * rate;

      grandHours += hours;
      grandPayroll += payroll;
      shiftCount += shifts;
      employeeCount++;

      html += `
        <tr>
          <td>${escapeHtml(getEmployeeName(pin))}</td>
          <td>${escapeHtml(formatMoney(rate))}</td>
          <td>${escapeHtml(formatHours(hours))}</td>
          <td>${escapeHtml(String(shifts))}</td>
          <td>${escapeHtml(formatMoney(payroll))}</td>
        </tr>
      `;
    });

  html += `
    <tr>
      <th>Total</th>
      <th>-</th>
      <th>${escapeHtml(formatHours(grandHours))}</th>
      <th>${escapeHtml(String(shiftCount))}</th>
      <th>${escapeHtml(formatMoney(grandPayroll))}</th>
    </tr>
  </table></div>`;

  document.getElementById("reportSummary").innerHTML = `
    <div class="summary-card"><strong>Range</strong><br>${escapeHtml(formatDateOnly(start))} - ${escapeHtml(formatDateOnly(end))}</div>
    <div class="summary-card"><strong>Employees</strong><br>${employeeCount}</div>
    <div class="summary-card"><strong>Total Hours</strong><br>${escapeHtml(formatHours(grandHours))}</div>
    <div class="summary-card"><strong>Total Shifts</strong><br>${shiftCount}</div>
    <div class="summary-card"><strong>Payroll Total</strong><br>${escapeHtml(formatMoney(grandPayroll))}</div>
  `;

  document.getElementById("reportOutput").innerHTML = html;
}

function printReport() {
  window.print();
}

/* ------------------------- Backup / Restore ------------------------- */

function backup() {
  const data = {
    employees,
    entries,
    exportedAt: new Date().toISOString(),
    retentionDays: DATA_RETENTION_DAYS
  };

  const blob = new Blob([JSON.stringify(data, null, 2)], {
    type: "application/json"
  });

  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "timeclock_backup.json";
  a.click();

  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

function restore() {
  const input = document.createElement("input");
  input.type = "file";
  input.accept = ".json,application/json";

  input.onchange = e => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();

    reader.onload = function () {
      try {
        const data = JSON.parse(reader.result);

        if (!data || typeof data !== "object") {
          throw new Error("Invalid backup file.");
        }

        if (typeof data.employees !== "object" || typeof data.entries !== "object") {
          throw new Error("Backup file is missing employees or entries.");
        }

        employees = data.employees;
        entries = data.entries;

        migrateData();
        cleanupOldData();
        save();

        safeMessage("Backup restored successfully.");

        if (!document.getElementById("manager").classList.contains("hidden")) {
          document.getElementById("managerContent").innerHTML = `
            <div class="empty-state">Backup restored. Choose an option above.</div>
          `;
        }
      } catch (error) {
        safeMessage("Restore failed: " + error.message);
      }
    };

    reader.readAsText(file);
  };

  input.click();
}

/* ------------------------- Navigation ------------------------- */

function backManager() {
  show("manager");
}

/* ------------------------- Startup ------------------------- */

document.addEventListener("DOMContentLoaded", () => {
  migrateData();
  cleanupOldData();
  updateLiveClocks();

  const pinInput = document.getElementById("pin");
  if (pinInput) {
    pinInput.addEventListener("keydown", e => {
      if (e.key === "Enter") login();
    });
  }

  if (!localStorage.getItem("employees")) save();

  // optional recurring cleanup while app stays open
  setInterval(cleanupOldData, 60 * 60 * 1000);
});
